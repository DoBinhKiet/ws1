import os
import numpy as np
import matplotlib.pyplot as plt
from model import planner
from solve import plan_allocations

# Set project directory
os.chdir("C:\\Users\\Laptop K1\\Downloads\\Stochastic_Growth_with_Labor_Kiet_ver2\\Python")
main = os.getcwd()

# Parameters for analysis
figout = main + "\\output\\figures"
if not os.path.exists(figout):
    os.makedirs(figout)

# Initialize model
benevolent_dictator = planner()

# Set the parameters, state space, and utility function
benevolent_dictator.setup(main=main, figout=figout, beta=0.96, sigma=2.00)

# Range of human capital policy parameters to analyze
u_values = np.linspace(0.1, 0.9, 10)
outputs = []

# Analyze the impact of human capital policy on output
for u in u_values:
    benevolent_dictator.par.u = u
    plan_allocations(benevolent_dictator)
    outputs.append(np.mean(benevolent_dictator.sol.y))

# Plot the results
plt.figure()
plt.plot(u_values, outputs, marker='o')
plt.xlabel('Human Capital Policy (u)')
plt.ylabel('Output')
plt.title('Impact of Human Capital Policy on Output')
plt.grid(True)

# Save the figure
figname = figout + "\\human_capital_impact.png"
plt.savefig(figname)
plt.show()
